import sys
sys.path.extend(["../"])
sys.path.extend(["."])
import warnings
warnings.filterwarnings("ignore")

import pickle
from sklearn import metrics

def read_test_data(url):
    with open(url, 'r') as file:
        data = [line.split(',') for line in file.read().split('\n')]
        data.pop(data.__len__() - 1)
        test_features = [[int(element) for element in row] for row in data]
        return test_features


def write_data_to_csv(_file, predicted):
    with open(_file, 'w') as file:
        for i in range(len(predicted)):
            file.write('%d,%d\n' % (i + 1, predicted[i]))

def load_model_with_test_data(_model_url , _test_data_url, fileName):
    with open(_model_url, 'rb') as file:
        classifier = pickle.load(file, encoding='latin1')
        test_features = read_test_data(_test_data_url)
        _val_pred = classifier.predict(test_features)
        write_data_to_csv(fileName, _val_pred)
        # print(_val_pred)
        # print(test_features)


#   classifier with daa sets 1 && 2
load_model_with_test_data("PickleFiles/ds1Model-dt.pkl", "ds1/ds1Test.csv", 'OutputFiles/ds1Test-dt.csv')
load_model_with_test_data("PickleFiles/ds2Model-dt.pkl", "ds2/ds2Test.csv", 'OutputFiles/ds2Test-dt.csv')

load_model_with_test_data("PickleFiles/ds1Model-nb.pkl", "ds1/ds1Test.csv", 'OutputFiles/ds1Test-nb.csv')
load_model_with_test_data("PickleFiles/ds2Model-nb.pkl", "ds2/ds2Test.csv", 'OutputFiles/ds2Test-nb.csv')

load_model_with_test_data("PickleFiles/ds1Model-3.pkl", "ds1/ds1Test.csv", 'OutputFiles/ds1Test-3.csv')
load_model_with_test_data("PickleFiles/ds2Model-3.pkl", "ds2/ds2Test.csv", 'OutputFiles/ds2Test-3.csv')

