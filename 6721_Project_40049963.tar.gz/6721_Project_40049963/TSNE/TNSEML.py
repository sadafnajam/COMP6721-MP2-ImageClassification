from sklearn import manifold
from sklearn import metrics
from sklearn.preprocessing import StandardScaler
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sn
import warnings
warnings.filterwarnings("ignore")

def read_csv_data(url):
    with open(url, 'r') as file:
        data = [line.split(',') for line in file.read().split('\n')]
        data.pop(data.__len__() - 1)
        data = [[int(element) for element in row] for row in data]
        return data
def firstDataSet(trainUrl , valUrl):
    #   reading train data
    _train_data = read_csv_data(trainUrl)
    _train_features = [d[:-1] for d in _train_data]
    _train_labels = [d[-1] for d in _train_data]
    data = pd.read_csv(trainUrl)
    inputs = data[data.columns[1:]]
    standardized_data = StandardScaler().fit_transform(inputs)
    print(standardized_data.shape)

    # TSNE

    # Picking the top 1000 points as TSNE takes a lot of time for 15K points
    index= 2
    model = manifold.TSNE(n_components=2, random_state=0,
                 perplexity=30)  # Random state should be mentioned if not the model will give different results in different iterations
    # configuring the parameteres
    # the number of components = 2
    # default perplexity = 30
    # default learning rate = 200
    # default Maximum number of iterations for the optimization = 1000

    _classifier = model.fit_transform(_train_features)

    # creating a new data frame which help us in ploting the result data
    _classifier = np.vstack((_classifier.T, _train_labels)).T  # converting whole matrix to column matrix
    tsne_df = pd.DataFrame(data=_classifier, columns=("Dim_1", "Dim_2", "label"))

    # Ploting the result of tsne
    sn.FacetGrid(tsne_df, hue="label", size=6).map(plt.scatter, 'Dim_1', 'Dim_2').add_legend()
    plt.show()

    plt.figure(figsize=(7, 7))
    idx = 10 - index
    # print(inputs.iloc[idx])
    grid_data = inputs.iloc[idx].as_matrix().reshape(32, 32)  # reshape from 1d to 2d pixel array
    plt.imshow(grid_data, interpolation="none", cmap="Oranges")
    plt.show()



def secondDataSet(trainUrl , valUrl):
    #   reading train data
    _train_data = read_csv_data(trainUrl)
    _train_features = [d[:-1] for d in _train_data]
    _train_labels = [d[-1] for d in _train_data]
    standardized_data = StandardScaler().fit_transform(_train_features)
    print(standardized_data.shape)
    data = pd.read_csv(trainUrl)
    inputs = data[data.columns[1:]]
    index= 2
    model = manifold.TSNE(n_components=2, random_state=0,
                          perplexity=30)  # Random state should be mentioned if not the model will give different results in different iterations
    # configuring the parameteres
    # the number of components = 2
    # default perplexity = 30
    # default learning rate = 200
    # default Maximum number of iterations for the optimization = 1000

    _classifier = model.fit_transform(_train_features)

    # creating a new data frame which help us in ploting the result data
    _classifier = np.vstack((_classifier.T, _train_labels)).T  # converting whole matrix to column matrix
    tsne_df = pd.DataFrame(data=_classifier, columns=("Dim_1", "Dim_2", "label"))

    # Ploting the result of tsne
    sn.FacetGrid(tsne_df, hue="label", size=6).map(plt.scatter, 'Dim_1', 'Dim_2').add_legend()
    plt.show()
    plt.figure(figsize=(7, 7))
    idx = 10 - index
    # print(inputs.iloc[idx])
    grid_data = inputs.iloc[idx].as_matrix().reshape(32, 32)  # reshape from 1d to 2d pixel array
    plt.imshow(grid_data, interpolation="none", cmap="gray")
    plt.show()

firstDataSet("ds1/ds1Train.csv", "ds1/ds1Val.csv")
secondDataSet("ds2/ds2Train.csv", "ds2/ds2Val.csv")