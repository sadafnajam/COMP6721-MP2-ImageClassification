from sklearn import naive_bayes
from sklearn import metrics
from sklearn.preprocessing import StandardScaler
import pickle
from sklearn.model_selection import  cross_val_score

def read_csv_data(url):
    with open(url, 'r') as file:
        data = [line.split(',') for line in file.read().split('\n')]
        data.pop(data.__len__() - 1)
        data = [[int(element) for element in row] for row in data]
        return data


def write_data_to_csv(_file, predicted):
    with open(_file, 'w') as file:
        for i in range(len(predicted)):
            file.write('%d,%d\n' % (i + 1, predicted[i]))


def save_model(_file, classifier):
    with open(_file, 'wb') as file:
        pickle.dump(classifier, file)


def show_all_report(_val_features, _val_labels, _val_pred):
    print(metrics.confusion_matrix(_val_labels, _val_pred))
    print(metrics.classification_report(_val_labels, _val_pred))
    print('Accuracy for nb-gaussian is %d%%:' % (metrics.accuracy_score(_val_labels, _val_pred) * float(100)))
    print("\n")
    # print('inst#        actual      predicted')
    # for i in range(len(_val_features)):
    #     print("%s           %s          %s" % ((i+1), _val_labels[i], _val_pred[i]))


def firstDataSet(trainUrl , valUrl):
    #   reading train data
    _train_data = read_csv_data(trainUrl)
    _train_features = [d[:-1] for d in _train_data]
    _train_labels = [d[-1] for d in _train_data]
    standardized_data = StandardScaler().fit_transform(_train_features)
    print(standardized_data.shape)
    _classifier = naive_bayes.GaussianNB()
    _classifier = _classifier.fit(_train_features, _train_labels)
    #   reading the validation data
    _validation_data = read_csv_data(valUrl)
    _val_features = [d[:-1] for d in _validation_data]
    _val_labels = [d[-1] for d in _validation_data]
    _val_pred = _classifier.predict(_val_features)
    save_model('NaiveBayesClassifier/ds1Model_GNB.pkl', _classifier)
    write_data_to_csv('NaiveBayesClassifier/ds1Result_GNB.csv', _val_pred)
    show_all_report(_val_features, _val_labels, _val_pred)
    # test the retuned best parameters
    _score = cross_val_score(_classifier, _train_features, _train_labels, cv=10)
    print("mean: {:.3f} (std: {:.3f})".format(_score.mean(),
                                              _score.std()))
def secondDataSet(trainUrl , valUrl):
    #   reading train data
    _train_data = read_csv_data(trainUrl)
    _train_features = [d[:-1] for d in _train_data]
    _train_labels = [d[-1] for d in _train_data]
    standardized_data = StandardScaler().fit_transform(_train_features)
    print(standardized_data.shape)
    _classifier = naive_bayes.GaussianNB()
    _classifier = _classifier.fit(_train_features, _train_labels)
    #   reading the validation data
    _validation_data = read_csv_data(valUrl)
    _val_features = [d[:-1] for d in _validation_data]
    _val_labels = [d[-1] for d in _validation_data]
    _val_pred = _classifier.predict(_val_features)
    save_model('NaiveBayesClassifier/ds2Model_GNB.pkl', _classifier)
    write_data_to_csv('NaiveBayesClassifier/ds2Result_GNB.csv', _val_pred)
    show_all_report(_val_features, _val_labels, _val_pred)
    # test the retuned best parameters
    _score = cross_val_score(_classifier, _train_features, _train_labels, cv=10)
    print("mean: {:.3f} (std: {:.3f})".format(_score.mean(),
                                              _score.std()))

firstDataSet("ds1/ds1Train.csv", "ds1/ds1Val.csv")
secondDataSet("ds2/ds2Train.csv", "ds2/ds2Val.csv")