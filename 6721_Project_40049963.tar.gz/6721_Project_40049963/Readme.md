python DecisionTree/DSTreeClassifier.py
python NaiveBayesClassifier/MultinomialNBML.py
python NaiveBayesClassifier/GaussianNBML.py     (Note : GuassianNB does not accept parameters)
python NaiveBayesClassifier/ComplementNBML.py
python NaiveBayesClassifier/BernoulliNBML.py
python KNeighborsClassifier/KNeighborsClassifierML.py
python svm/SupportVectorMachineML.py

graph------
python TSNE/TNSEML.py