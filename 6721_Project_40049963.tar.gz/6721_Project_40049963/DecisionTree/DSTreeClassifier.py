from sklearn import tree
from sklearn import metrics
from sklearn.preprocessing import StandardScaler
import pickle
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import cross_val_score, StratifiedKFold
import warnings
warnings.filterwarnings("ignore")

def read_csv_data(url):
    with open(url, 'r') as file:
        data = [line.split(',') for line in file.read().split('\n')]
        data.pop(data.__len__() - 1)
        data = [[int(element) for element in row] for row in data]
        return data

def write_data_to_csv(_file, predicted):
    with open(_file, 'w') as file:
        for i in range(len(predicted)):
            file.write('%d,%d\n' % (i + 1, predicted[i]))

def save_model(_file, classifier):
    with open(_file, 'wb') as file:
        pickle.dump(classifier, file)

def show_all_report(_val_features, _val_labels, _val_pred):
    print(metrics.confusion_matrix(_val_labels, _val_pred))
    print(metrics.classification_report(_val_labels, _val_pred))
    print('Accuracy for decision tree is %d%%:' % (metrics.accuracy_score(_val_labels, _val_pred) * float(100)))
    print("\n")
    # print('inst#        actual      predicted')
    # for i in range(len(_val_features)):
    #     print("%s           %s          %s" % ((i+1), _val_labels[i], _val_pred[i]))


def tuning_with_grid_search(trainUrl):
    _train_data = read_csv_data(trainUrl)
    _train_features = [d[:-1] for d in _train_data]
    _train_labels = [d[-1] for d in _train_data]
    _decision_tree = tree.DecisionTreeClassifier()
    print(_decision_tree.get_params())
    parameters = {'max_depth': range(3, 20), "criterion": ["gini", "entropy"]}
    cross_validation = StratifiedKFold( n_splits=10)
    clf = GridSearchCV(estimator=_decision_tree, param_grid=parameters, cv=cross_validation)
    clf.fit(X=_train_features, y=_train_labels)
    print(clf.best_score_, clf.best_params_)


def tuning_with_looping(trainUrl, valUrl):
    _train_data = read_csv_data(trainUrl)
    _train_features = [d[:-1] for d in _train_data]
    _train_labels = [d[-1] for d in _train_data]
    _validation_data = read_csv_data(valUrl)
    _val_features = [d[:-1] for d in _validation_data]
    _val_labels = [d[-1] for d in _validation_data]
    for i in range(3, 30):
        # _dt = tree.DecisionTreeClassifier(max_depth=i, criterion='entropy')
        # _dt = tree.DecisionTreeClassifier(max_depth=i, criterion='gini')
        _dt = tree.DecisionTreeClassifier(max_depth=i)
        _dt.fit(_train_features, _train_labels)
        pred = _dt.predict(_val_features)
        # evaluate accuracy
        acc = metrics.accuracy_score(_val_labels, pred, normalize=True) * float(100)
        print('\nTree accuracy for dt = %d is %d%%' % (i, acc))

def firstDataSet(trainUrl , valUrl):
    #   reading train data
    _train_data = read_csv_data(trainUrl)
    _train_features = [d[:-1] for d in _train_data]
    _train_labels = [d[-1] for d in _train_data]
    standardized_data = StandardScaler().fit_transform(_train_features)
    print(standardized_data.shape)
    _classifier = tree.DecisionTreeClassifier(criterion='entropy', max_depth=15)
    _classifier = _classifier.fit(_train_features, _train_labels)
    #   reading the validation data
    _validation_data = read_csv_data(valUrl)
    _val_features = [d[:-1] for d in _validation_data]
    _val_labels = [d[-1] for d in _validation_data]
    _val_pred = _classifier.predict(_val_features)
    save_model('DecisionTree/ds1Model-dt.pkl', _classifier)
    write_data_to_csv('DecisionTree/ds1Val-dt.csv', _val_pred)
    show_all_report(_val_features, _val_labels, _val_pred)
    # test the retuned best parameters
    _score = cross_val_score(_classifier, _train_features, _train_labels, cv=10)
    print("mean: {:.3f} (std: {:.3f})".format(_score.mean(),
                                              _score.std()))
def secondDataSet(trainUrl , valUrl):
    #   reading train data
    _train_data = read_csv_data(trainUrl)
    _train_features = [d[:-1] for d in _train_data]
    _train_labels = [d[-1] for d in _train_data]
    standardized_data = StandardScaler().fit_transform(_train_features)
    print(standardized_data.shape)
    _classifier = tree.DecisionTreeClassifier(criterion='gini', max_depth=18)
    _classifier = _classifier.fit(_train_features, _train_labels)
    _validation_data = read_csv_data(valUrl)
    _val_features = [d[:-1] for d in _validation_data]
    _val_labels = [d[-1] for d in _validation_data]
    _val_pred = _classifier.predict(_val_features)
    save_model('DecisionTree/ds2Model-dt.pkl', _classifier)
    write_data_to_csv('DecisionTree/ds2Val-dt.csv', _val_pred)
    show_all_report(_val_features, _val_labels, _val_pred)
    # test the retuned best parameters
    _score = cross_val_score(_classifier, _train_features, _train_labels, cv=10)
    print("mean: {:.3f} (std: {:.3f})".format(_score.mean(),
                                              _score.std()))

firstDataSet("ds1/ds1Train.csv", "ds1/ds1Val.csv")
secondDataSet("ds2/ds2Train.csv", "ds2/ds2Val.csv")
# tuning_with_grid_search("ds1/ds1Train.csv")
# tuning_with_looping("ds1/ds1Train.csv", "ds1/ds1Val.csv")
# tuning_with_grid_search("ds2/ds2Train.csv")
# tuning_with_looping("ds2/ds2Train.csv", "ds2/ds2Val.csv")



