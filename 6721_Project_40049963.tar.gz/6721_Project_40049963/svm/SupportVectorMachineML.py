from sklearn import svm
from sklearn import metrics
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import GridSearchCV
import pickle
from sklearn.model_selection import cross_val_score
from sklearn.metrics import accuracy_score
import warnings
warnings.filterwarnings("ignore")

def read_csv_data(url):
    with open(url, 'r') as file:
        data = [line.split(',') for line in file.read().split('\n')]
        data.pop(data.__len__() - 1)
        data = [[int(element) for element in row] for row in data]
        return data

def write_data_to_csv(_file, predicted):
    with open(_file, 'w') as file:
        for i in range(len(predicted)):
            file.write('%d,%d\n' % (i + 1, predicted[i]))


def save_model(_file, classifier):
    with open(_file, 'wb') as file:
        pickle.dump(classifier, file)


def show_all_report(_val_features, _val_labels, _val_pred):
    print(metrics.confusion_matrix(_val_labels, _val_pred))
    print(metrics.classification_report(_val_labels, _val_pred))
    print('Accuracy for svm is %d%%:' % (metrics.accuracy_score(_val_labels, _val_pred) * float(100)))
    print("\n")
    # print('inst#        actual      predicted')
    # for i in range(len(_val_features)):
    #     print("%s           %s          %s" % ((i+1), _val_labels[i], _val_pred[i]))


def tuning_with_grid_search(trainUrl):
    _train_data = read_csv_data(trainUrl)
    _train_features = [d[:-1] for d in _train_data]
    _train_labels = [d[-1] for d in _train_data]
    Cs = [0.01, 0.001, 0.1, 1]
    gammas = [0.01, 0.001, 0.1, 1]
    param_grid = {'C': Cs, 'gamma': gammas}
    grid_search = GridSearchCV(svm.SVC(kernel='poly'), param_grid, cv=10)
    grid_search.fit(_train_features, _train_labels)
    print(grid_search.best_params_)


def tuning_with_looping(trainUrl, valUrl):
    _train_data = read_csv_data(trainUrl)
    _train_features = [d[:-1] for d in _train_data]
    _train_labels = [d[-1] for d in _train_data]
    _validation_data = read_csv_data(valUrl)
    _val_features = [d[:-1] for d in _validation_data]
    _val_labels = [d[-1] for d in _validation_data]
    for i in range(1, 5):
        svc = svm.SVC(C=i*10, kernel='poly')
        svc.fit(_train_features, _train_labels)
        pred = svc.predict(_val_features)
        # evaluate CV accuracy
        acc = accuracy_score(_val_labels, pred, normalize=True) * float(100)
        print('\nTree accuracy for svm = %f is %f%%' % (i, acc))

def firstDataSet(trainUrl , valUrl):
    #   reading train data
    _train_data = read_csv_data(trainUrl)
    _train_features = [d[:-1] for d in _train_data]
    _train_labels = [d[-1] for d in _train_data]
    standardized_data = StandardScaler().fit_transform(_train_features)
    print(standardized_data.shape)
    _classifier = svm.SVC(kernel='linear')
    _classifier = _classifier.fit(_train_features, _train_labels)
    classifier = svm.SVC(C=0.01, kernel='poly', gamma=0.01)
    classifier.fit(_train_features, _train_labels)
    #   reading the validation data
    _validation_data = read_csv_data(valUrl)
    _val_features = [d[:-1] for d in _validation_data]
    _val_labels = [d[-1] for d in _validation_data]
    _val_pred = classifier.predict(_val_features)
    save_model('svm/ds1Model-3.pkl', classifier)
    write_data_to_csv('svm/ds1Val-3.csv', _val_pred)
    show_all_report(_val_features, _val_labels, _val_pred)
    # test the retuned best parameters
    _score = cross_val_score(_classifier, _train_features, _train_labels, cv=10)
    print("mean: {:.3f} (std: {:.3f})".format(_score.mean(),
                                              _score.std()))
def secondDataSet(trainUrl , valUrl):
    #   reading train data
    _train_data = read_csv_data(trainUrl)
    _train_features = [d[:-1] for d in _train_data]
    _train_labels = [d[-1] for d in _train_data]
    standardized_data = StandardScaler().fit_transform(_train_features)
    print(standardized_data.shape)
    classifier = svm.SVC(C=0.01, kernel='poly', gamma=0.01)
    classifier.fit(_train_features, _train_labels)
    #   reading the validation data
    _validation_data = read_csv_data(valUrl)
    _val_features = [d[:-1] for d in _validation_data]
    _val_labels = [d[-1] for d in _validation_data]
    _val_pred = classifier.predict(_val_features)
    save_model('svm/ds2Model-3.pkl', classifier)
    write_data_to_csv('svm/ds2Val-3.csv', _val_pred)
    show_all_report(_val_features, _val_labels, _val_pred)
    # test the retuned best parameters
    _score = cross_val_score(classifier, _train_features, _train_labels, cv=10)
    print("mean: {:.3f} (std: {:.3f})".format(_score.mean(),
                                              _score.std()))

firstDataSet("ds1/ds1Train.csv", "ds1/ds1Val.csv")
secondDataSet("ds2/ds2Train.csv", "ds2/ds2Val.csv")
# tuning_with_grid_search("ds1/ds1Train.csv")
# tuning_with_looping("ds1/ds1Train.csv", "ds1/ds1Val.csv")
# tuning_with_grid_search("ds2/ds2Train.csv")
# tuning_with_looping("ds2/ds2Train.csv", "ds2/ds2Val.csv")